# Cookly

Kotlin, Jetpack Compose, Material 3, Retrofit, Coil y Room. SDK mínimo 24.

## Abrir en Mac

1. Descomprime el ZIP y abre la carpeta Cookly desde Android Studio.
2. Selecciona JDK 21 para Gradle. Deja que Android Studio detecte el SDK de tu Mac.
3. Sincroniza Gradle e inicia app en un emulador o dispositivo Android.

Se necesita Internet para descargar las dependencias, consultar platos y cargar sus fotos. Los favoritos se conservan en Room. El ZIP no contiene local.properties ni rutas de otro equipo.

Los datos se consultan en https://dev.codemcy.com/dishes.php. La búsqueda envía el parámetro pais al servidor. Las fotos utilizan las direcciones de esa API y muestran un aviso si el proveedor de una imagen no responde.

El resumen muestra la suma de precios y el IGV (18% de la suma), con dos decimales. No se presupone una moneda porque la API no la indica.

Verificación: assembleDebug y testDebugUnitTest completados con JDK 21. Cuatro pruebas correctas. Compilado en Linux; pendiente de ejecución visual en tu emulador o dispositivo.
