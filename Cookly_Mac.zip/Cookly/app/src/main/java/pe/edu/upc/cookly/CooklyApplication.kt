package pe.edu.upc.cookly

import android.app.Application
import androidx.room.Room
import pe.edu.upc.cookly.data.DishRepositoryImpl
import pe.edu.upc.cookly.data.local.CooklyDatabase
import pe.edu.upc.cookly.data.remote.DishService
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

class CooklyApplication : Application() {
    val repository by lazy {
        val database = Room.databaseBuilder(this, CooklyDatabase::class.java, "cookly.db").build()
        val client = OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS).build()
        val service = Retrofit.Builder().baseUrl("https://dev.codemcy.com/")
            .client(client).addConverterFactory(GsonConverterFactory.create()).build()
            .create(DishService::class.java)
        DishRepositoryImpl(service, database.favoriteDao())
    }
}
