package pe.edu.upc.cookly.data

import kotlinx.coroutines.flow.map
import pe.edu.upc.cookly.data.local.FavoriteDao
import pe.edu.upc.cookly.data.local.toEntity
import pe.edu.upc.cookly.data.remote.DishService
import pe.edu.upc.cookly.domain.Dish
import pe.edu.upc.cookly.domain.DishRepository

class DishRepositoryImpl(private val service: DishService, private val dao: FavoriteDao) : DishRepository {
    override val favorites = dao.observeFavorites().map { list -> list.map { it.toDomain() } }
    override suspend fun getDishes(country: String?) = service.getDishes(country).map { it.toDomain() }
    override suspend fun addFavorite(dish: Dish) = dao.insert(dish.toEntity())
    override suspend fun removeFavorite(dish: Dish) = dao.delete(dish.id)
}
