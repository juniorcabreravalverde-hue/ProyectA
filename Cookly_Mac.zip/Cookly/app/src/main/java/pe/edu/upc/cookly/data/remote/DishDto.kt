package pe.edu.upc.cookly.data.remote

import com.google.gson.annotations.SerializedName
import pe.edu.upc.cookly.domain.Dish
import java.math.BigDecimal
import java.math.RoundingMode

data class DishDto(
    val id: String,
    @SerializedName("nombre") val name: String,
    @SerializedName("descripcion") val description: String,
    @SerializedName("ingredientes") val ingredients: List<String>,
    @SerializedName("pais") val country: String,
    @SerializedName("tipo") val type: String,
    @SerializedName("precio") val price: BigDecimal,
    @SerializedName("foto") val photo: String
) {
    fun toDomain() = Dish(id, name, description, ingredients, country, type,
        price.movePointRight(2).setScale(0, RoundingMode.HALF_UP).longValueExact(), photo)
}
