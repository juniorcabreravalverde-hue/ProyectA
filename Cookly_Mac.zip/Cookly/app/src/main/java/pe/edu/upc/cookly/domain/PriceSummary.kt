package pe.edu.upc.cookly.domain

import java.math.BigDecimal
import java.math.RoundingMode

data class PriceSummary(val count: Int, val totalCents: Long, val taxCents: Long)

fun summarizePrices(dishes: List<Dish>): PriceSummary {
    val total = dishes.sumOf { it.priceCents }
    val tax = BigDecimal.valueOf(total).multiply(BigDecimal("0.18"))
        .setScale(0, RoundingMode.HALF_UP).longValueExact()
    return PriceSummary(dishes.size, total, tax)
}

fun formatPrice(cents: Long): String = BigDecimal.valueOf(cents, 2).toPlainString()
