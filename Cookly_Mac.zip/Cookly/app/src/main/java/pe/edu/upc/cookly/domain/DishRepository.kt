package pe.edu.upc.cookly.domain

import kotlinx.coroutines.flow.Flow

interface DishRepository {
    val favorites: Flow<List<Dish>>
    suspend fun getDishes(country: String? = null): List<Dish>
    suspend fun addFavorite(dish: Dish)
    suspend fun removeFavorite(dish: Dish)
}
