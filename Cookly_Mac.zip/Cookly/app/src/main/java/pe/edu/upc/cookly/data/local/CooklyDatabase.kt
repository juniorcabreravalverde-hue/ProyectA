package pe.edu.upc.cookly.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(entities = [FavoriteEntity::class], version = 1, exportSchema = false)
@TypeConverters(IngredientConverter::class)
abstract class CooklyDatabase : RoomDatabase() {
    abstract fun favoriteDao(): FavoriteDao
}
