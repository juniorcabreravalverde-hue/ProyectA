package pe.edu.upc.cookly.data.remote

import retrofit2.http.GET
import retrofit2.http.Query

interface DishService {
    @GET("dishes.php")
    suspend fun getDishes(@Query("pais") country: String? = null): List<DishDto>
}
