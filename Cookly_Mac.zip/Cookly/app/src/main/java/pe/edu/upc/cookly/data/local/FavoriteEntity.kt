package pe.edu.upc.cookly.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import pe.edu.upc.cookly.domain.Dish

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val ingredients: List<String>,
    val country: String,
    val type: String,
    val priceCents: Long,
    val photo: String
) {
    fun toDomain() = Dish(id, name, description, ingredients, country, type, priceCents, photo)
}

fun Dish.toEntity() = FavoriteEntity(id, name, description, ingredients, country, type, priceCents, photo)
