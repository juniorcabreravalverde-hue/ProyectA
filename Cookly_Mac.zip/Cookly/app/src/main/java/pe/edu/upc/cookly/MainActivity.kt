package pe.edu.upc.cookly

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import pe.edu.upc.cookly.presentation.CooklyApp
import pe.edu.upc.cookly.presentation.CooklyViewModel
import pe.edu.upc.cookly.presentation.CooklyTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val repository = (application as CooklyApplication).repository
        setContent {
            CooklyTheme {
                val viewModel: CooklyViewModel = viewModel(factory = CooklyViewModel.Factory(repository))
                CooklyApp(viewModel)
            }
        }
    }
}
