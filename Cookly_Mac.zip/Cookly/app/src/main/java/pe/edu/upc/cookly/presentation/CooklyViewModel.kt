package pe.edu.upc.cookly.presentation

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collect
import pe.edu.upc.cookly.domain.Dish
import pe.edu.upc.cookly.domain.DishRepository

// Cada consulta mantiene su propio estado; buscar por país no altera el catálogo.
data class DishListState(
    val loading: Boolean = false,
    val dishes: List<Dish> = emptyList(),
    val error: String? = null,
    val searched: Boolean = false
)

data class FavoriteChange(val dish: Dish, val add: Boolean)

class CooklyViewModel(private val repository: DishRepository) : ViewModel() {
    var catalog by mutableStateOf(DishListState())
        private set
    var search by mutableStateOf(DishListState())
        private set
    var country by mutableStateOf("")
    var favorites by mutableStateOf<List<Dish>>(emptyList())
        private set
    var selectedDish by mutableStateOf<Dish?>(null)
    var pendingChange by mutableStateOf<FavoriteChange?>(null)
        private set
    var saving by mutableStateOf(false)
        private set
    var favoriteError by mutableStateOf<String?>(null)
        private set
    private var searchJob: Job? = null
    private var catalogJob: Job? = null

    init {
        viewModelScope.launch {
            try { repository.favorites.collect { favorites = it } }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { favoriteError = "No se pudieron leer los favoritos." }
        }
        loadCatalog()
    }

    fun loadCatalog() {
        catalogJob?.cancel()
        catalogJob = viewModelScope.launch {
            catalog = DishListState(loading = true)
            try { catalog = DishListState(dishes = repository.getDishes(), searched = true) }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { catalog = DishListState(error = "No se pudieron cargar los platos. Revisa tu conexión y vuelve a intentar.") }
        }
    }

    fun searchCountry() {
        val term = country.trim()
        searchJob?.cancel()
        if (term.isEmpty()) {
            search = DishListState(error = "Escribe un país para buscar.")
            return
        }
        searchJob = viewModelScope.launch {
            search = DishListState(loading = true)
            try { search = DishListState(dishes = repository.getDishes(term), searched = true) }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { search = DishListState(error = "No se pudo realizar la búsqueda. Vuelve a intentar.") }
        }
    }

    fun requestFavorite(dish: Dish, add: Boolean) {
        if (!saving) { favoriteError = null; pendingChange = FavoriteChange(dish, add) }
    }

    fun cancelFavorite() { if (!saving) pendingChange = null }
    fun clearError() { favoriteError = null }

    // La base cambia solo después de aceptar la confirmación.
    fun confirmFavorite() {
        val change = pendingChange ?: return
        if (saving) return
        viewModelScope.launch {
            saving = true
            try {
                if (change.add) repository.addFavorite(change.dish) else repository.removeFavorite(change.dish)
                pendingChange = null
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { favoriteError = "No se pudo guardar el cambio. Inténtalo otra vez." }
            finally { saving = false }
        }
    }

    class Factory(private val repository: DishRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = CooklyViewModel(repository) as T
    }
}
