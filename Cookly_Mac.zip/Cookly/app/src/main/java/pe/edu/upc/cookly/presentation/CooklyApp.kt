package pe.edu.upc.cookly.presentation

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.SubcomposeAsyncImage
import pe.edu.upc.cookly.R
import pe.edu.upc.cookly.domain.Dish
import pe.edu.upc.cookly.domain.formatPrice
import pe.edu.upc.cookly.domain.summarizePrices

private val Ink = Color(0xFF11131A)
private val Panel = Color(0xFF1B1E27)
private val Accent = Color(0xFFFFC857)

@Composable
fun CooklyTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Accent, onPrimary = Ink,
        background = Ink, surface = Panel,
        secondary = Color(0xFF8ED8C2)
    ), content = content)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CooklyApp(viewModel: CooklyViewModel) {
    var screen by rememberSaveable { mutableStateOf("home") }
    val selected = viewModel.selectedDish
    val favorites = viewModel.favorites
    val title = if (selected != null) "Detalle del plato" else when (screen) {
        "all" -> "Platos"
        "country" -> "Platos por país"
        "favorites" -> "Favoritos"
        else -> "Cookly"
    }
    fun goBack() {
        if (viewModel.selectedDish != null) viewModel.selectedDish = null else screen = "home"
    }
    BackHandler(enabled = selected != null || screen != "home") { goBack() }
    Scaffold(
        topBar = {
            TopAppBar(title = { Text(title, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    if (selected != null || screen != "home") IconButton(onClick = { goBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Volver")
                    }
                })
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            if (selected != null) {
                val isFavorite = favorites.any { it.id == selected.id }
                DetailScreen(selected, isFavorite, viewModel.saving) {
                    viewModel.requestFavorite(selected, !isFavorite)
                }
            } else when (screen) {
                "all" -> DishListScreen(viewModel.catalog, viewModel::loadCatalog) { viewModel.selectedDish = it }
                "country" -> CountryScreen(viewModel) { viewModel.selectedDish = it }
                "favorites" -> FavoritesScreen(favorites,
                    onOpen = { viewModel.selectedDish = it },
                    onRemove = { viewModel.requestFavorite(it, false) })
                else -> HomeScreen { screen = it }
            }
        }
    }
    viewModel.pendingChange?.let { change ->
        AlertDialog(
            onDismissRequest = viewModel::cancelFavorite,
            title = { Text(if (change.add) "Agregar a favoritos" else "Eliminar de favoritos") },
            text = { Text(if (change.add) "¿Quieres agregar ${change.dish.name} a tus favoritos?"
                else "¿Quieres eliminar ${change.dish.name} de tus favoritos?") },
            confirmButton = { TextButton(onClick = viewModel::confirmFavorite, enabled = !viewModel.saving) {
                Text(if (viewModel.saving) "Guardando…" else "Aceptar")
            } },
            dismissButton = { TextButton(onClick = viewModel::cancelFavorite, enabled = !viewModel.saving) { Text("Cancelar") } }
        )
    }
    viewModel.favoriteError?.let { message ->
        AlertDialog(onDismissRequest = viewModel::clearError,
            title = { Text("No se pudo completar la acción") },
            text = { Text(message) },
            confirmButton = { TextButton(onClick = viewModel::clearError) { Text("Cerrar") } })
    }
}

@Composable
private fun HomeScreen(onNavigate: (String) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.fillMaxWidth().padding(24.dp)) {
                    Image(painterResource(R.drawable.ic_launcher), "Marca Cookly", Modifier.size(86.dp).clip(RoundedCornerShape(22.dp)))
                    Spacer(Modifier.height(20.dp))
                    Text("SABORES DEL MUNDO", color = Accent, fontSize = 11.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(10.dp))
                    Text("Tu próxima aventura\nempieza en un plato.", fontSize = 30.sp, lineHeight = 36.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    Text("Descubre platos, conoce sus ingredientes y guarda tus favoritos.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item { HomeButton("Platos", "Explora todos los sabores", Icons.Default.Restaurant) { onNavigate("all") } }
        item { HomeButton("Platos por país", "Encuentra un destino en cada receta", Icons.Default.Public) { onNavigate("country") } }
        item { HomeButton("Favoritos", "Los platos que quieres volver a ver", Icons.Default.Favorite) { onNavigate("favorites") } }
    }
}

@Composable
private fun HomeButton(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Accent, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.AutoMirrored.Filled.ArrowForward, null, Modifier.size(20.dp))
        }
    }
}

@Composable
private fun DishListScreen(state: DishListState, onRetry: () -> Unit, onOpen: (Dish) -> Unit) {
    when {
        state.loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        state.error != null -> MessagePanel(state.error, "Reintentar", onRetry)
        state.dishes.isEmpty() -> MessagePanel("No se encontraron platos.")
        else -> LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            items(state.dishes, key = { it.id }) { dish -> DishCard(dish, onOpen = { onOpen(dish) }) }
        }
    }
}

@Composable
private fun CountryScreen(viewModel: CooklyViewModel, onOpen: (Dish) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(value = viewModel.country, onValueChange = { viewModel.country = it },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                label = { Text("País") }, placeholder = { Text("Ej. Perú, Chile o Bolivia") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { viewModel.searchCountry() }))
            Text("Respeta los acentos o escribe parte del país: por ejemplo, Per.", fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(onClick = viewModel::searchCountry, modifier = Modifier.fillMaxWidth()) { Text("Buscar") }
        }
        Box(Modifier.weight(1f)) {
            if (!viewModel.search.searched && viewModel.search.error == null && !viewModel.search.loading) {
                MessagePanel("Escribe un país y pulsa Buscar.")
            } else DishListScreen(viewModel.search, viewModel::searchCountry, onOpen)
        }
    }
}

@Composable
private fun DishCard(dish: Dish, onOpen: () -> Unit, showPrice: Boolean = false, onRemove: (() -> Unit)? = null) {
    Card(onClick = onOpen, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
        DishPhoto(dish, Modifier.fillMaxWidth().height(180.dp))
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(dish.country.uppercase(), fontSize = 11.sp, color = Accent, letterSpacing = 1.sp)
            Text(dish.name, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text(dish.description, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (showPrice) Text("Precio: ${formatPrice(dish.priceCents)}", fontWeight = FontWeight.Bold, color = Accent)
            if (onRemove != null) OutlinedButton(onClick = onRemove) {
                Icon(Icons.Default.DeleteOutline, null, Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Eliminar de favoritos")
            }
        }
    }
}

@Composable
private fun DishPhoto(dish: Dish, modifier: Modifier) {
    SubcomposeAsyncImage(model = dish.photo, contentDescription = dish.name, modifier = modifier,
        contentScale = ContentScale.Crop,
        loading = { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(Modifier.size(26.dp)) } },
        error = { Column(Modifier.fillMaxSize().background(Panel), verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.ImageNotSupported, null, tint = Accent)
            Text("Imagen no disponible", fontSize = 12.sp)
        } })
}

@Composable
private fun DetailScreen(dish: Dish, isFavorite: Boolean, saving: Boolean, onFavorite: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { DishPhoto(dish, Modifier.fillMaxWidth().height(240.dp).clip(RoundedCornerShape(24.dp))) }
        item {
            Text("${dish.country} · ${dish.type}", color = Accent)
            Text(dish.name, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        }
        item { Text(dish.description, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item {
            Text("Ingredientes", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            dish.ingredients.forEach { Text("• $it", Modifier.padding(vertical = 3.dp)) }
        }
        item { Text("Precio: ${formatPrice(dish.priceCents)}", fontSize = 24.sp, color = Accent, fontWeight = FontWeight.Bold) }
        item {
            Button(onClick = onFavorite, enabled = !saving, modifier = Modifier.fillMaxWidth()) {
                Icon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null)
                Spacer(Modifier.width(10.dp))
                Text(if (isFavorite) "Quitar de favoritos" else "Agregar a favoritos")
            }
        }
    }
}

@Composable
private fun FavoritesScreen(favorites: List<Dish>, onOpen: (Dish) -> Unit, onRemove: (Dish) -> Unit) {
    val summary = summarizePrices(favorites)
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Platos favoritos", fontWeight = FontWeight.Bold)
                    Text(summary.count.toString(), color = Accent, fontWeight = FontWeight.Bold)
                }
            }
        }
        if (favorites.isEmpty()) item { Text("Todavía no tienes favoritos. Abre un plato y agrégalo desde su detalle.") }
        items(favorites, key = { it.id }) { dish ->
            DishCard(dish, onOpen = { onOpen(dish) }, showPrice = true, onRemove = { onRemove(dish) })
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Resumen", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    SummaryRow("Suma de precios", formatPrice(summary.totalCents))
                    SummaryRow("IGV (18%)", formatPrice(summary.taxCents))
                }
            }
        }
    }
}

@Composable
private fun SummaryRow(label: String, amount: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, Modifier.weight(1f))
        Text(amount, color = Accent, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun MessagePanel(message: String, buttonText: String? = null, onClick: () -> Unit = {}) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text(message)
        if (buttonText != null) { Spacer(Modifier.height(12.dp)); Button(onClick = onClick) { Text(buttonText) } }
    }
}
