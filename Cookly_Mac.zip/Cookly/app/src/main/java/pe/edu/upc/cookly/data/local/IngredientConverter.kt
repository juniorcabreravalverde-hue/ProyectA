package pe.edu.upc.cookly.data.local

import androidx.room.TypeConverter
import com.google.gson.Gson

class IngredientConverter {
    @TypeConverter fun encode(value: List<String>): String = Gson().toJson(value)
    @TypeConverter fun decode(value: String): List<String> =
        Gson().fromJson(value, Array<String>::class.java).toList()
}
