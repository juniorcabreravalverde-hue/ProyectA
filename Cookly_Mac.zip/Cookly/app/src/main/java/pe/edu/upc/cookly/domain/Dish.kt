package pe.edu.upc.cookly.domain

data class Dish(
    val id: String,
    val name: String,
    val description: String,
    val ingredients: List<String>,
    val country: String,
    val type: String,
    val priceCents: Long,
    val photo: String
)
