package pe.edu.upc.cookly

import org.junit.Assert.assertEquals
import org.junit.Test
import pe.edu.upc.cookly.domain.*

class PriceSummaryTest {
    private fun dish(id: String, cents: Long) = Dish(id, "Plato", "", emptyList(), "Perú", "", cents, "")

    @Test fun totalAndTaxAreRoundedToCents() {
        val summary = summarizePrices(listOf(dish("1", 2590), dish("2", 3850), dish("3", 3400)))
        assertEquals(3, summary.count)
        assertEquals(9840L, summary.totalCents)
        assertEquals(1771L, summary.taxCents)
        assertEquals("17.71", formatPrice(summary.taxCents))
    }
    @Test fun emptyFavoritesHaveZeroCountAndAmounts() {
        assertEquals(PriceSummary(0, 0, 0), summarizePrices(emptyList()))
        assertEquals("0.00", formatPrice(0))
    }
    @Test fun removingADishRecalculatesTheSummary() {
        val dishes = listOf(dish("1", 2590), dish("2", 3850))
        val summary = summarizePrices(dishes.filterNot { it.id == "1" })
        assertEquals(PriceSummary(1, 3850, 693), summary)
    }
}
