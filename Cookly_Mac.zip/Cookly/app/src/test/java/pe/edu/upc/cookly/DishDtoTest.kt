package pe.edu.upc.cookly

import com.google.gson.Gson
import org.junit.Assert.assertEquals
import org.junit.Test
import pe.edu.upc.cookly.data.remote.DishDto

class DishDtoTest {
    @Test fun mapsSpanishApiFieldsAndIngredientArray() {
        val json = """{"id":"2001","nombre":"Ceviche","descripcion":"Pescado",
            "ingredientes":["Pescado blanco","Limón"],"pais":"Perú","tipo":"Entrada",
            "precio":25.9,"foto":"https://example.com/ceviche.jpg"}"""
        val dish = Gson().fromJson(json, DishDto::class.java).toDomain()
        assertEquals("2001", dish.id)
        assertEquals("Ceviche", dish.name)
        assertEquals(listOf("Pescado blanco", "Limón"), dish.ingredients)
        assertEquals("Perú", dish.country)
        assertEquals(2590L, dish.priceCents)
    }
}
